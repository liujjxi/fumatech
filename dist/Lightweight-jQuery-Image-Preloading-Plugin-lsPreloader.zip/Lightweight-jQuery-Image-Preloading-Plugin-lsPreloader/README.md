# Plugin | lsPreloader
Plugin de pré carregamento de imagens para jQuery.


- Desenvolvido em: 2013
